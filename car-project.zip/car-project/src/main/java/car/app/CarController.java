package car.app;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import car.app.calc.InputReader;
import car.app.calc.PriceCalculator;
import car.app.entity.CalculatorData;
import car.app.entity.Car;

@RestController
@RequestMapping("car")
public class CarController {
	
	@Autowired
	private InputReader reader;
	
	@Autowired
	private PriceCalculator calc;
	
	public void getCars() {
		
		CalculatorData data = reader.excelReader();
		
		calc.validate(data);
		calc.calculate(data);
		
		HashMap<Car, Double> carPriceMap = data.getOutputMap();
		
		System.out.println("Car Number: Price");
		
		carPriceMap.entrySet().stream().forEach(
				e -> System.out.println(e.getKey().getCarNumber() + ": " + e.getValue()) );
		
	}

}
