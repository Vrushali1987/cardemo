package car.app.entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CalculatorData {
	
	private final List<Car> carlist;
	private final List<String> errorList;
	private final HashMap<Car, Double> outputMap;
	
	public CalculatorData(){
		carlist = new ArrayList<Car>();
		errorList = new ArrayList<String>();
		outputMap = new HashMap<Car, Double> ();
	}
	
	public List<Car> getCarlist() {
		return carlist;
	}	
	
	public List<String> getErrorList() {
		return errorList;
	}
	
	public HashMap<Car, Double> getOutputMap() {
		return outputMap;
	}
}
