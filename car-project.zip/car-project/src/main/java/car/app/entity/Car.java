package car.app.entity;

public class Car {

	private double carNumber;
	private double price;
	private String color;
	private int noWheelDrive;
	private boolean amphibious;
	
	
	public double getCarNumber() {
		return carNumber;
	}
	public void setCarNumber(double d) {
		this.carNumber = d;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double d) {
		this.price = d;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getNoWheelDrive() {
		return noWheelDrive;
	}
	public void setNoWheelDrive(int noWheelDrive) {
		this.noWheelDrive = noWheelDrive;
	}
	public boolean isAmphibious() {
		return amphibious;
	}
	public void setAmphibious(boolean amphibious) {
		this.amphibious = amphibious;
	}	
}
