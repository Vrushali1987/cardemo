package car.app.entity;

public class CarConstant {

	public static final double BASE_PRICE_MULTIPLIER = 1.2;
	public static final double BASE_PRICE_LIMIT = 150;
	public static final int CHROMATIC_PRICE_COLOR = 500;
	public static final int FOUR_WHEELER = 4;
	public static final int AMPHIBIOUS_PRICE = 2000;
	
}
