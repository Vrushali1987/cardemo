package car.app.calc;

import car.app.entity.CalculatorData;

public interface PriceCalculator {

	public void calculate(CalculatorData output);
	
	
	
}
