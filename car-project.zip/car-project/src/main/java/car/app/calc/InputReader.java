package car.app.calc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import car.app.entity.CalculatorData;
import car.app.entity.Car;

public class InputReader {
	
	public CalculatorData excelReader() {
		
		CalculatorData input = new CalculatorData();
		List<Car> carList = input.getCarlist();
		List errorList = input.getErrorList();
		
		try {
			URL resource = getClass().getClassLoader().getResource("car-lot.csv");
	        FileInputStream excelFile;
			
			excelFile = new FileInputStream(new File(resource.toURI()));
			
	        Workbook workbook = new XSSFWorkbook(excelFile);
	        Sheet datatypeSheet = workbook.getSheetAt(0);
	        Iterator<Row> iterator = datatypeSheet.iterator();
	
	        while (iterator.hasNext()) {
	
	            Row currentRow = iterator.next();          
	            validateCar(currentRow, carList, errorList);     
	
	        }
	    } catch (URISyntaxException|FileNotFoundException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		
		return input;
		
	}

	private void validateCar(Row currentRow, List<Car> carList, List errorList) {
		Car car = new Car();	
		List<String> newErrors = new ArrayList();
		
			
		if(currentRow.getCell(0).getCellTypeEnum()==CellType.NUMERIC)
			car.setCarNumber(currentRow.getCell(0).getNumericCellValue());
		else
			newErrors.add(currentRow.getCell(0) + ": Car number is incorrect.");
			
		if(currentRow.getCell(1).getCellTypeEnum()==CellType.NUMERIC)
			car.setPrice(currentRow.getCell(1).getNumericCellValue());
		else
			newErrors.add(currentRow.getCell(0) + ": Price should be numeric.");
		
		if(currentRow.getCell(3).getCellTypeEnum()==CellType.NUMERIC)
			car.setNoWheelDrive((int)currentRow.getCell(3).getNumericCellValue());
		else
			newErrors.add(currentRow.getCell(0) + ": No of wheels should be Numeric");
		
		if(currentRow.getCell(2).getCellTypeEnum()==CellType.STRING) {
			car.setColor(currentRow.getCell(2).getStringCellValue());
		}
		else
			newErrors.add(currentRow.getCell(0) + ": Color is incorrect");
		
		if(currentRow.getCell(4).getCellTypeEnum()==CellType.BOOLEAN) {
			car.setColor(currentRow.getCell(4).getStringCellValue());
		}
		else
			newErrors.add(currentRow.getCell(0) + ": AMPHIBIOUS must be boolean value");
			
		
		if(newErrors.isEmpty())
			carList.add(car);
		
		errorList.add(newErrors);
	}

}
