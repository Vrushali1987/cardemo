package car.app.calc;

import java.util.Collections;
import java.util.HashMap;

import org.springframework.stereotype.Component;

import com.sun.tools.javac.util.List;

import car.app.entity.CalculatorData;
import car.app.entity.Car;
import car.app.entity.CarConstant;
import car.app.entity.SortByCarNumber;

@Component
public class PriceCalculatorImpl implements PriceCalculator{

	@Override
	public void calculate(CalculatorData data) {
		
		addValidData(data);
		HashMap<Car, Double> carMap = data.getOutputMap();
		
		carMap.entrySet().forEach(m -> {
			
			Car c = m.getKey();
			double finalPrice = calculatePrice(c);
			m.setValue(finalPrice);
			
		});
	}


	
	private double calculatePrice(Car c) {
		double finalPrice=0.0;
		double basePrice = c.getPrice();
		if(basePrice > CarConstant.BASE_PRICE_LIMIT)
			finalPrice = CarConstant.BASE_PRICE_MULTIPLIER * basePrice;
		
		if("METALLIC".equals(c.getColor()) || "CHROMATIC".equals(c.getColor()) )
			finalPrice = finalPrice + CarConstant.CHROMATIC_PRICE_COLOR;
		
		if(c.getNoWheelDrive()>= CarConstant.FOUR_WHEELER && c.isAmphibious())
			finalPrice = finalPrice + CarConstant.AMPHIBIOUS_PRICE;
		
		return finalPrice;
	}



	private void addValidData(CalculatorData data) {
		//Validation is taken care during reading data. Here we are adding Valid data to outputMap
		
		List<Car> carList = (List<Car>) data.getCarlist();
		Collections.sort(carList, new SortByCarNumber());
		
		HashMap map = data.getOutputMap();
		carList.forEach(c -> 
		{
			map.put(c, 0.0);
		});
		
		
		
		return true;
	}

}
